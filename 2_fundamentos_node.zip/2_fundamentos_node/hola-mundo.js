//let sirve para declarar variable de alcance local
let nombre = 'Pedro';
console.log(nombre);

nombre = 'Juan';
console.log(nombre);

console.log('Hola Mundo');