let nombre = 'Anner';
//console.log ('Hola' + nombre);
console.log(`Hola ${nombre}`);
