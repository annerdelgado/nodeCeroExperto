const fs = require('node:fs');// de esta forma se rquieren paquetes (cambia en cada version)
require('colors');

const crearArchivoTabla = async (base,listar,hasta) => {

    try {
        let salida, consola = '';

        for (let i = 1; i <= hasta; i++) {
            salida += (`${base} x ${i} = ${base * i}\n`);
            consola += (`${base} ${'x'.yellow} ${i} ${'='.red} ${base * i}\n`);
        }

        if(listar){
            console.log(consola);
        }

        // fs.writeFile( `tabla-${base}.txt`, salida, (err) => { //asi se crea un archivo en los directorios
        //     if (err) throw err;
        //     console.log(`tabla-${base}.txt creada`);
        // });

        fs.writeFileSync(`./salida/tabla-${base}.txt`, salida);
        return `tabla-${base}.txt`;

    } catch (err) {
        throw err
    }
}

module.exports = {
    crearArchivoTabla
}