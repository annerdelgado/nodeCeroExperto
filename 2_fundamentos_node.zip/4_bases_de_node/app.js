// npm init (esto genera el package.json)
// npm run base3 (esto corre el script que guardamos en el package.json(verlo en el archivo))
// npm install colors (al instalar este paquete se genero como una dependencia)
// npm install nodemon --save-dev (se instala solo para desarrollo sin ser dependencia(devDependencies))
// npm uninstall nodemon (para desinstalar paquetes)
// npm i colors@1.0.0 (para instalar version especifica)
// npm update (busca las dependencias que hayan y las actualiza)
// npm install (busca en el package.json los paquetes necesarios y los instala si no existe node_modules)


const { crearArchivoTabla } = require('./helpers/multiplicar');
const argv = require('./config/yargs');
require('colors');
// const colors = require('colors');


console.clear();

// console.log(process.argv);

// console.log(argv);

// const [,,arg3 = 'base=1']= process.argv;
// const [,base=1]= arg3.split('=');


crearArchivoTabla(argv.b, argv.l, argv.h)
    .then(nombreArchivo => console.log(`${nombreArchivo.rainbow} creado`))
    .catch(err => console.log(err));