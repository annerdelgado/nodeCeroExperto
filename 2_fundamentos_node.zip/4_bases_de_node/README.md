# Notas:
Primer programa en node

```
Opciones:
      --help     Muestra ayuda                                        [booleano]
      --version  Muestra número de versión                            [booleano]
  -b, --base     Es la base de la tabla de multiplicar      [número] [requerido]
  -l, --listar   Muestra la tabla de multiplicar     [booleano] [defecto: false]
  -h, --hasta    Es el limte de la tabla de multiplicar   [número] [defecto: 10]
  ```