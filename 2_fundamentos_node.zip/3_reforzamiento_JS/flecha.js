/* function sumar(a,b){
    return a + b;
} */

/* const sumar = (a, b) =>{
    return a + b;
} */

const sumar = (a, b) => a + b;//tambien es funcion de flecha y se usa asi cuando solo se hace el return (o sea solo tiene una linea)
const saludar = () => 'Hola Mundo';

console.log(sumar(5,10));
console.log(saludar());