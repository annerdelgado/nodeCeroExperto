/*var nombre = 'Pedro';

if (true){
    var nombre = 'Jesus';
}
var nombre = 'Maria';
var nombre = 'Jose';
console.log(nombre);*/


/*let nombre = 'Andrea';
if(true){
    let nombre = 'Cristina';
}
console.log(nombre);*/


/*for (var i=0; i<=5; i++){
    console.log(`i: ${i}`);
}

console.log(i);*/


let i = 'Desarrollo Web';

for (let i=0; i<=5; i++){
    console.log(`i: ${i}`);
}

console.log(i);