let nombre ='Pepito';

if (true){
    let nombre ='Magneto';
}

console.log(nombre);
