const nombre = 'iron man';
const real = 'tony stark';

const normal = nombre + ', ' + real;
//const template = `${1 + 1} Juan`;
const template = `${nombre}, ${real}`;
console.log(normal);
console.log(template); 
console.log(normal === template);

const html = `
<h1>Hola</h1>
<p>Mundo>/p>`;
console.log(html);